I1 = imread('lap2.jpg');
I= rgb2gray(I1);
subplot(1,2,1);
imshow(I);
[r,c]=size(I);

x= c * 0.20;
y= r * 0.20;

x1= (c-2*x);
y1= (r-2*y);
I2 = imcrop(I,[x, y, x1,y1]);
subplot(1,2,2);
imshow(I2)

img2= I2;
img3= I2;


 [m,n]=size(img2);

   for x = 1:m
            for y = 1:n
                m=double(img2(x,y));
                img2(x,y)=120.*log10(1+m);
            end
   end
   
    [p,q]=size(img2);
 
    for x = 1:p
            for y = 1:q
                if(img2(x,y)>200)
                   img3(x,y)=255;
                else
                    img3(x,y)=0;
                end
            end
    end
  
  figure(1); 
  imshow(img2)
  title('orignal image')
  
  figure,
  subplot(1,1,1);
  imshow(img3)
  title('bit clip image')
  
  

[p,q]=size(img3);
 for x = 1:p
            for y = 1:q
                if((x==p)||(y==q))
                   img3(x,y)=255;
                
                end
            end
 end
    
    for x = 1:p-1
            for y = 1:q-1
                if((img3(x,y)==0)&&(img3(x,y+1)==0)&&(img3(x+1,y)==0)&&(img3(x+1,y+1)==0))
                   img3(x,y)=0;
                else
                    img3(x,y)=255;
                end
            end
    end
    
    
  figure,
  subplot(1,1,1);
  imshow(img3)
  title('final image')
  
  [p,q]=size(img3);
 
    for x = 1:p-1
            for y = 1:q-1
                if((img3(x,y)==0)&&(img3(x,y+1)==0)&&(img3(x+1,y)==0)&&(img3(x+1,y+1)==0))
                   img3(x,y)=0;
                else
                    img3(x,y)=255;
                end
            end
    end
    
  
  figure,
  imshow(img3);
  title('full and final image1')
  
  
    [p,q]=size(img3);
 
    for x = 1:p-1
            for y = 1:q-1
                if((img3(x,y)==0)&&(img3(x,y+1)==0)&&(img3(x+1,y)==0)&&(img3(x+1,y+1)==0))
                   img3(x,y)=0;
                else
                    img3(x,y)=255;
                end
            end
    end
    
  
  figure,
  imshow(img3);
  title('full and final image abc')
  
  
  
  [p,q]=size(img3);
  startx=0;
  endx=0;
  disp(['row ', num2str(p)]);
  disp(['col ', num2str(q)]);
    for x = 1:p
            for y = 1:q
                if(img3(x,y)==0)
                   startx=x;
                   break;
                end
            end
    end
    
    for x=p:-1:1
         for y=q:-1:1
            if(img3(x,y)==0)
                endx=x;
                   break;
            end
          end
    end      
    
disp(['start ', num2str(startx)]);
disp(['endx ', num2str(endx)]);

height1= startx-endx;
disp(['height1 ', num2str(height1)]);
disp('end of 1');

%********************************************************************
%********************************************************************
%********************************************************************

